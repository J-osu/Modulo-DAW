use empresa;

show create table ediciones;